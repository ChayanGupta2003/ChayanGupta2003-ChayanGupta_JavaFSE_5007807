

// ExcelDocumentImpl.java
public class ExcelDocumentImpl implements ExcelDocument {
    @Override
    public void create() {
        System.out.println("Creating Excel Document");
    }
}
