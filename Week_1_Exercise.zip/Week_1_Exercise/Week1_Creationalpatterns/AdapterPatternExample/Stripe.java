// Stripe.java
public class Stripe {
    public void pay(double amount) {
        System.out.println("Processing payment of Rs." + amount + " through Stripe.");
    }
}
